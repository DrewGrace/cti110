#This program demos how the range function can be used with a for loop

def main():
    #Print A message 5 times.
    for x in range(5):
        print('hello world!')

#call the main function.
main()
